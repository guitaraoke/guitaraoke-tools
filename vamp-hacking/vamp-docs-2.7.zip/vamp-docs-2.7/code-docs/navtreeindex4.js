var NAVTREEINDEX4 =
{
"vamp_8h.html#ae26a9d54a92f1c083a1b209a25a8e44e":[2,0,34,8],
"vamp_8h.html#afb59eb6e4ea5b47fc300435e98e8aa1b":[2,0,34,16],
"vamp_8h_source.html":[2,0,34]
};
