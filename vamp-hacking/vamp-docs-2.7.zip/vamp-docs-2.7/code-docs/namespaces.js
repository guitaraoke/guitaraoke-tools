var namespaces =
[
    [ "Vamp", "namespaceVamp.html", "namespaceVamp" ]
];