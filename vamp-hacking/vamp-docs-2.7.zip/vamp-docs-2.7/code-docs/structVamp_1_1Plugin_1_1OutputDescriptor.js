var structVamp_1_1Plugin_1_1OutputDescriptor =
[
    [ "SampleType", "structVamp_1_1Plugin_1_1OutputDescriptor.html#abffa9ed50cd756df70fd51f0355f448c", [
      [ "OneSamplePerStep", "structVamp_1_1Plugin_1_1OutputDescriptor.html#abffa9ed50cd756df70fd51f0355f448ca0459d5d0d2198d21e8bc90abe4fdccca", null ],
      [ "FixedSampleRate", "structVamp_1_1Plugin_1_1OutputDescriptor.html#abffa9ed50cd756df70fd51f0355f448ca4c74bd2fc96dfe2815623f94b40e5629", null ],
      [ "VariableSampleRate", "structVamp_1_1Plugin_1_1OutputDescriptor.html#abffa9ed50cd756df70fd51f0355f448cadea995a737867f7b22b52f1c43c5432e", null ]
    ] ],
    [ "OutputDescriptor", "structVamp_1_1Plugin_1_1OutputDescriptor.html#a1ebf91cc3f60e4cbba818c10591cd344", null ],
    [ "identifier", "structVamp_1_1Plugin_1_1OutputDescriptor.html#ae2c893ddb1860589517ab7eaa989a18b", null ],
    [ "name", "structVamp_1_1Plugin_1_1OutputDescriptor.html#ab824b2b34ee50f897a30901c620e8d87", null ],
    [ "description", "structVamp_1_1Plugin_1_1OutputDescriptor.html#af9b4fe8f78e7126ead820ba5dc55efd1", null ],
    [ "unit", "structVamp_1_1Plugin_1_1OutputDescriptor.html#aa057a8833fa037f06ac9f7b85b85d5e4", null ],
    [ "hasFixedBinCount", "structVamp_1_1Plugin_1_1OutputDescriptor.html#af0e577e1a256ff6eed6ea42133fec77d", null ],
    [ "binCount", "structVamp_1_1Plugin_1_1OutputDescriptor.html#afdd006959a995e40ef7d565a3a4df6dc", null ],
    [ "binNames", "structVamp_1_1Plugin_1_1OutputDescriptor.html#a31d9b79e2d8241344f551a22fcb5c8c7", null ],
    [ "hasKnownExtents", "structVamp_1_1Plugin_1_1OutputDescriptor.html#ae9ccb65f99f477096b65dd031f4c5e31", null ],
    [ "minValue", "structVamp_1_1Plugin_1_1OutputDescriptor.html#ac9f5924c0be7571bba8e7ae7e7a921f4", null ],
    [ "maxValue", "structVamp_1_1Plugin_1_1OutputDescriptor.html#a907b4e8fbb48a46ac5a05f880d72719f", null ],
    [ "isQuantized", "structVamp_1_1Plugin_1_1OutputDescriptor.html#a1b4858928d23bfd7d5bc557c82a83fb4", null ],
    [ "quantizeStep", "structVamp_1_1Plugin_1_1OutputDescriptor.html#a3bed37153067b625b95acb40b60dbf0b", null ],
    [ "sampleType", "structVamp_1_1Plugin_1_1OutputDescriptor.html#a0d1194980d44e31b25ef3b4b070d6b5d", null ],
    [ "sampleRate", "structVamp_1_1Plugin_1_1OutputDescriptor.html#add0cbbdfa9c91764037c39365b1d42af", null ],
    [ "hasDuration", "structVamp_1_1Plugin_1_1OutputDescriptor.html#ab0d7cc6ab19e53b5bd12ee234f549ea3", null ]
];