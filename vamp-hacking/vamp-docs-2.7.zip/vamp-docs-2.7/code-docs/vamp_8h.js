var vamp_8h =
[
    [ "_VampParameterDescriptor", "struct__VampParameterDescriptor.html", "struct__VampParameterDescriptor" ],
    [ "_VampOutputDescriptor", "struct__VampOutputDescriptor.html", "struct__VampOutputDescriptor" ],
    [ "_VampFeature", "struct__VampFeature.html", "struct__VampFeature" ],
    [ "_VampFeatureV2", "struct__VampFeatureV2.html", "struct__VampFeatureV2" ],
    [ "_VampFeatureUnion", "union__VampFeatureUnion.html", "union__VampFeatureUnion" ],
    [ "_VampFeatureList", "struct__VampFeatureList.html", "struct__VampFeatureList" ],
    [ "_VampPluginDescriptor", "struct__VampPluginDescriptor.html", "struct__VampPluginDescriptor" ],
    [ "VAMP_API_VERSION", "vamp_8h.html#a6d6c8c755dbabf161f72712e0e2143c7", null ],
    [ "VampParameterDescriptor", "vamp_8h.html#ae26a9d54a92f1c083a1b209a25a8e44e", null ],
    [ "VampOutputDescriptor", "vamp_8h.html#aa8429dd9c60d65800c58574c2b06bf66", null ],
    [ "VampFeature", "vamp_8h.html#a8d04355c13e5ff7a146abcb168cb919f", null ],
    [ "VampFeatureV2", "vamp_8h.html#a41cb3518127d0971b1d2c8edfbbe2763", null ],
    [ "VampFeatureUnion", "vamp_8h.html#a2517349f1c97e0c59faab6085e092fcd", null ],
    [ "VampFeatureList", "vamp_8h.html#a5f257e3f8b5ca1ca4c159d486e219078", null ],
    [ "VampPluginHandle", "vamp_8h.html#ad3be2952b1f4ad7d775940a6db75c79b", null ],
    [ "VampPluginDescriptor", "vamp_8h.html#aa1d6e0792099b9516a89b5fb7ed2ad2b", null ],
    [ "VampGetPluginDescriptorFunction", "vamp_8h.html#afb59eb6e4ea5b47fc300435e98e8aa1b", null ],
    [ "VampSampleType", "vamp_8h.html#aa24a8cee023d8b7659d25cbe0584b821", [
      [ "vampOneSamplePerStep", "vamp_8h.html#aa24a8cee023d8b7659d25cbe0584b821ab546deafd57f175fb1e7f9cbea1c5113", null ],
      [ "vampFixedSampleRate", "vamp_8h.html#aa24a8cee023d8b7659d25cbe0584b821aafc8a05f722bc83ecce227e12e838cf8", null ],
      [ "vampVariableSampleRate", "vamp_8h.html#aa24a8cee023d8b7659d25cbe0584b821abae8a21a9e30eb73e16d6abc6c7415e8", null ]
    ] ],
    [ "VampInputDomain", "vamp_8h.html#ab107386a5f042feddf6446bea23bb765", [
      [ "vampTimeDomain", "vamp_8h.html#ab107386a5f042feddf6446bea23bb765ae3dbb77ff3e8f292966fd3748888e1a1", null ],
      [ "vampFrequencyDomain", "vamp_8h.html#ab107386a5f042feddf6446bea23bb765aee0c1c0d429276f071b8c0730b7bd87d", null ]
    ] ],
    [ "vampGetPluginDescriptor", "vamp_8h.html#a50cf6f17d0718f02093be6c7f63fcf30", null ]
];