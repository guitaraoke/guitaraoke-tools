var files =
[
    [ "AmplitudeFollower.cpp", "AmplitudeFollower_8cpp.html", null ],
    [ "AmplitudeFollower.h", "AmplitudeFollower_8h.html", [
      [ "AmplitudeFollower", "classAmplitudeFollower.html", "classAmplitudeFollower" ]
    ] ],
    [ "doc-overview", "doc-overview.html", null ],
    [ "FFT.h", "FFT_8h.html", [
      [ "FFT", "classVamp_1_1FFT.html", "classVamp_1_1FFT" ],
      [ "FFTComplex", "classVamp_1_1FFTComplex.html", "classVamp_1_1FFTComplex" ],
      [ "FFTReal", "classVamp_1_1FFTReal.html", "classVamp_1_1FFTReal" ]
    ] ],
    [ "FixedTempoEstimator.cpp", "FixedTempoEstimator_8cpp.html", "FixedTempoEstimator_8cpp" ],
    [ "FixedTempoEstimator.h", "FixedTempoEstimator_8h.html", [
      [ "FixedTempoEstimator", "classFixedTempoEstimator.html", "classFixedTempoEstimator" ]
    ] ],
    [ "host-c.h", "host-c_8h.html", "host-c_8h" ],
    [ "hostguard.h", "hostguard_8h.html", "hostguard_8h" ],
    [ "PercussionOnsetDetector.cpp", "PercussionOnsetDetector_8cpp.html", null ],
    [ "PercussionOnsetDetector.h", "PercussionOnsetDetector_8h.html", [
      [ "PercussionOnsetDetector", "classPercussionOnsetDetector.html", "classPercussionOnsetDetector" ]
    ] ],
    [ "plugguard.h", "plugguard_8h.html", "plugguard_8h" ],
    [ "vamp-sdk/Plugin.h", "vamp-sdk_2Plugin_8h.html", [
      [ "Plugin", "classVamp_1_1Plugin.html", "classVamp_1_1Plugin" ],
      [ "OutputDescriptor", "structVamp_1_1Plugin_1_1OutputDescriptor.html", "structVamp_1_1Plugin_1_1OutputDescriptor" ],
      [ "Feature", "structVamp_1_1Plugin_1_1Feature.html", "structVamp_1_1Plugin_1_1Feature" ]
    ] ],
    [ "vamp-hostsdk/Plugin.h", "vamp-hostsdk_2Plugin_8h.html", null ],
    [ "PluginAdapter.h", "PluginAdapter_8h.html", [
      [ "PluginAdapterBase", "classVamp_1_1PluginAdapterBase.html", "classVamp_1_1PluginAdapterBase" ],
      [ "PluginAdapter", "classVamp_1_1PluginAdapter.html", "classVamp_1_1PluginAdapter" ]
    ] ],
    [ "vamp-sdk/PluginBase.h", "vamp-sdk_2PluginBase_8h.html", [
      [ "PluginBase", "classVamp_1_1PluginBase.html", "classVamp_1_1PluginBase" ],
      [ "ParameterDescriptor", "structVamp_1_1PluginBase_1_1ParameterDescriptor.html", "structVamp_1_1PluginBase_1_1ParameterDescriptor" ]
    ] ],
    [ "vamp-hostsdk/PluginBase.h", "vamp-hostsdk_2PluginBase_8h.html", null ],
    [ "PluginBufferingAdapter.h", "PluginBufferingAdapter_8h.html", [
      [ "PluginBufferingAdapter", "classVamp_1_1HostExt_1_1PluginBufferingAdapter.html", "classVamp_1_1HostExt_1_1PluginBufferingAdapter" ]
    ] ],
    [ "PluginChannelAdapter.h", "PluginChannelAdapter_8h.html", [
      [ "PluginChannelAdapter", "classVamp_1_1HostExt_1_1PluginChannelAdapter.html", "classVamp_1_1HostExt_1_1PluginChannelAdapter" ]
    ] ],
    [ "PluginHostAdapter.h", "PluginHostAdapter_8h.html", [
      [ "PluginHostAdapter", "classVamp_1_1PluginHostAdapter.html", "classVamp_1_1PluginHostAdapter" ]
    ] ],
    [ "PluginInputDomainAdapter.h", "PluginInputDomainAdapter_8h.html", [
      [ "PluginInputDomainAdapter", "classVamp_1_1HostExt_1_1PluginInputDomainAdapter.html", "classVamp_1_1HostExt_1_1PluginInputDomainAdapter" ]
    ] ],
    [ "PluginLoader.h", "PluginLoader_8h.html", [
      [ "PluginLoader", "classVamp_1_1HostExt_1_1PluginLoader.html", "classVamp_1_1HostExt_1_1PluginLoader" ]
    ] ],
    [ "plugins.cpp", "plugins_8cpp.html", "plugins_8cpp" ],
    [ "PluginSummarisingAdapter.h", "PluginSummarisingAdapter_8h.html", [
      [ "PluginSummarisingAdapter", "classVamp_1_1HostExt_1_1PluginSummarisingAdapter.html", "classVamp_1_1HostExt_1_1PluginSummarisingAdapter" ]
    ] ],
    [ "PluginWrapper.h", "PluginWrapper_8h.html", [
      [ "PluginWrapper", "classVamp_1_1HostExt_1_1PluginWrapper.html", "classVamp_1_1HostExt_1_1PluginWrapper" ]
    ] ],
    [ "PowerSpectrum.cpp", "PowerSpectrum_8cpp.html", null ],
    [ "PowerSpectrum.h", "PowerSpectrum_8h.html", [
      [ "PowerSpectrum", "classPowerSpectrum.html", "classPowerSpectrum" ]
    ] ],
    [ "vamp-sdk/RealTime.h", "vamp-sdk_2RealTime_8h.html", "vamp-sdk_2RealTime_8h" ],
    [ "vamp-hostsdk/RealTime.h", "vamp-hostsdk_2RealTime_8h.html", null ],
    [ "SpectralCentroid.cpp", "SpectralCentroid_8cpp.html", null ],
    [ "SpectralCentroid.h", "SpectralCentroid_8h.html", [
      [ "SpectralCentroid", "classSpectralCentroid.html", "classSpectralCentroid" ]
    ] ],
    [ "system.h", "system_8h.html", "system_8h" ],
    [ "vamp-hostsdk.h", "vamp-hostsdk_8h.html", null ],
    [ "vamp-sdk.h", "vamp-sdk_8h.html", null ],
    [ "vamp-simple-host.cpp", "vamp-simple-host_8cpp.html", "vamp-simple-host_8cpp" ],
    [ "vamp.h", "vamp_8h.html", "vamp_8h" ],
    [ "ZeroCrossing.cpp", "ZeroCrossing_8cpp.html", null ],
    [ "ZeroCrossing.h", "ZeroCrossing_8h.html", [
      [ "ZeroCrossing", "classZeroCrossing.html", "classZeroCrossing" ]
    ] ]
];