var annotated_dup =
[
    [ "Vamp", "namespaceVamp.html", "namespaceVamp" ],
    [ "_VampFeature", "struct__VampFeature.html", "struct__VampFeature" ],
    [ "_VampFeatureList", "struct__VampFeatureList.html", "struct__VampFeatureList" ],
    [ "_VampFeatureUnion", "union__VampFeatureUnion.html", "union__VampFeatureUnion" ],
    [ "_VampFeatureV2", "struct__VampFeatureV2.html", "struct__VampFeatureV2" ],
    [ "_VampOutputDescriptor", "struct__VampOutputDescriptor.html", "struct__VampOutputDescriptor" ],
    [ "_VampParameterDescriptor", "struct__VampParameterDescriptor.html", "struct__VampParameterDescriptor" ],
    [ "_VampPluginDescriptor", "struct__VampPluginDescriptor.html", "struct__VampPluginDescriptor" ],
    [ "AmplitudeFollower", "classAmplitudeFollower.html", "classAmplitudeFollower" ],
    [ "FixedTempoEstimator", "classFixedTempoEstimator.html", "classFixedTempoEstimator" ],
    [ "PercussionOnsetDetector", "classPercussionOnsetDetector.html", "classPercussionOnsetDetector" ],
    [ "PowerSpectrum", "classPowerSpectrum.html", "classPowerSpectrum" ],
    [ "SpectralCentroid", "classSpectralCentroid.html", "classSpectralCentroid" ],
    [ "ZeroCrossing", "classZeroCrossing.html", "classZeroCrossing" ]
];