var classVamp_1_1FFTReal =
[
    [ "FFTReal", "classVamp_1_1FFTReal.html#a322be62b02d4dce71271d1b6af69310d", null ],
    [ "~FFTReal", "classVamp_1_1FFTReal.html#ade37f8ce309792f154b6e3b20cc23ad1", null ],
    [ "forward", "classVamp_1_1FFTReal.html#a25dfbb5bf24bdc4da8409ffdc3d827da", null ],
    [ "inverse", "classVamp_1_1FFTReal.html#a95921330e3be266b59a4eb94c5879fbe", null ],
    [ "m_d", "classVamp_1_1FFTReal.html#a7161d0e61886644b362392fa7df03104", null ]
];