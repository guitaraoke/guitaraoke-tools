var classVamp_1_1PluginAdapterBase =
[
    [ "~PluginAdapterBase", "classVamp_1_1PluginAdapterBase.html#aaa8afd318b6c3da108e1cbcc7e46603d", null ],
    [ "PluginAdapterBase", "classVamp_1_1PluginAdapterBase.html#a5dad6a9b4b170c0f284962e125ac988e", null ],
    [ "getDescriptor", "classVamp_1_1PluginAdapterBase.html#ad24595002512f9f00e8e45216d6f5dfb", null ],
    [ "createPlugin", "classVamp_1_1PluginAdapterBase.html#a9116adb9b7a426f4f0ded15e45a5531b", null ],
    [ "m_impl", "classVamp_1_1PluginAdapterBase.html#a0e3594c54884efd5a7ef38030645745b", null ]
];