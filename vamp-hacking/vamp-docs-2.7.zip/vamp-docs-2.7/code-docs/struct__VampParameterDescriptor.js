var struct__VampParameterDescriptor =
[
    [ "identifier", "struct__VampParameterDescriptor.html#a26d74afd6a3341a673f15955031845ab", null ],
    [ "name", "struct__VampParameterDescriptor.html#abba810bce9656f6002777f6c3f655957", null ],
    [ "description", "struct__VampParameterDescriptor.html#a95489272d6cf5a5b487e949da8e4fac6", null ],
    [ "unit", "struct__VampParameterDescriptor.html#a8ca235f816b56dc99125e010eee08fc7", null ],
    [ "minValue", "struct__VampParameterDescriptor.html#ab59c84f0bbe0d4d0c578d893c087b0db", null ],
    [ "maxValue", "struct__VampParameterDescriptor.html#a6e7646babdb265c4abfc107ba4350d80", null ],
    [ "defaultValue", "struct__VampParameterDescriptor.html#a3d37f986ee152ab55feb9902b35f7aca", null ],
    [ "isQuantized", "struct__VampParameterDescriptor.html#a3f41e3b6b69c7a95ff0ce8625794f83a", null ],
    [ "quantizeStep", "struct__VampParameterDescriptor.html#a68c91fd3fc0b0b3617c2d343fe32d0e5", null ],
    [ "valueNames", "struct__VampParameterDescriptor.html#a188883325ab1e4a898e3dc53a8f88f9d", null ]
];