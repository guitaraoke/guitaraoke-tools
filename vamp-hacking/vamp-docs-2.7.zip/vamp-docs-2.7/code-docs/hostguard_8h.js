var hostguard_8h =
[
    [ "_VAMP_IN_HOSTSDK", "hostguard_8h.html#a1b285975a7781cd1d1cdc19b0256380f", null ],
    [ "VAMP_SDK_VERSION", "hostguard_8h.html#a9b7a8e1ac1c91366bec5f2f33c137a2f", null ],
    [ "VAMP_SDK_MAJOR_VERSION", "hostguard_8h.html#ab5f7da6acf45065a6c7b7cd38a0bf588", null ],
    [ "VAMP_SDK_MINOR_VERSION", "hostguard_8h.html#ad5eef1e2154b42769cd642d2a1d42257", null ],
    [ "_VAMP_SDK_HOSTSPACE_BEGIN", "hostguard_8h.html#aef42eae5f1b0b897d8dac58cd54afbcd", null ],
    [ "_VAMP_SDK_HOSTSPACE_END", "hostguard_8h.html#a0e6efdc2909bdb0cfab70e087d91b171", null ],
    [ "_VAMP_SDK_PLUGSPACE_BEGIN", "hostguard_8h.html#a1a2724ea453971288d3218e4eab3072c", null ],
    [ "_VAMP_SDK_PLUGSPACE_END", "hostguard_8h.html#ac879bb1077ecc6132ea3581ef9033753", null ]
];