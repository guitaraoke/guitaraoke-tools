var struct__VampFeatureList =
[
    [ "featureCount", "struct__VampFeatureList.html#a01db33a31ae5e04a4bd097f4b6aa75f1", null ],
    [ "features", "struct__VampFeatureList.html#a103c817094643ac5ff4410768f4f92a7", null ]
];