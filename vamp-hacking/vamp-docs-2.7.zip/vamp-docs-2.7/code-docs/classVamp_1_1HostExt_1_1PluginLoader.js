var classVamp_1_1HostExt_1_1PluginLoader =
[
    [ "PluginKey", "classVamp_1_1HostExt_1_1PluginLoader.html#a473645bbb3ac5c1a0da2f0f482947c4d", null ],
    [ "PluginKeyList", "classVamp_1_1HostExt_1_1PluginLoader.html#a0d48b76e4f995110f53e0feeb23f733a", null ],
    [ "PluginCategoryHierarchy", "classVamp_1_1HostExt_1_1PluginLoader.html#ad6a39aa0c79d8d9209eb0b8dfe9d1364", null ],
    [ "AdapterFlags", "classVamp_1_1HostExt_1_1PluginLoader.html#aff3ee11692ce25e0dfb904324cbe3494", [
      [ "ADAPT_INPUT_DOMAIN", "classVamp_1_1HostExt_1_1PluginLoader.html#aff3ee11692ce25e0dfb904324cbe3494a763a9a0caf512d9671b90c05c2808a09", null ],
      [ "ADAPT_CHANNEL_COUNT", "classVamp_1_1HostExt_1_1PluginLoader.html#aff3ee11692ce25e0dfb904324cbe3494a54c43b85382d78e8ea8da192bce3a139", null ],
      [ "ADAPT_BUFFER_SIZE", "classVamp_1_1HostExt_1_1PluginLoader.html#aff3ee11692ce25e0dfb904324cbe3494a5c0c389797922630a6b54ffd1eed21f1", null ],
      [ "ADAPT_ALL_SAFE", "classVamp_1_1HostExt_1_1PluginLoader.html#aff3ee11692ce25e0dfb904324cbe3494a8220529e851ae30d37f413c40a389e08", null ],
      [ "ADAPT_ALL", "classVamp_1_1HostExt_1_1PluginLoader.html#aff3ee11692ce25e0dfb904324cbe3494a3b1e08415c0cbc96f7900eac955ad6d0", null ]
    ] ],
    [ "PluginLoader", "classVamp_1_1HostExt_1_1PluginLoader.html#a5ab9e0281244bef7976c6c0ce1a55c24", null ],
    [ "~PluginLoader", "classVamp_1_1HostExt_1_1PluginLoader.html#ad74ab52bc6aa2514b3a6b3f679fc492c", null ],
    [ "getInstance", "classVamp_1_1HostExt_1_1PluginLoader.html#a1d77fa1d58ee4fee2985b5af02380326", null ],
    [ "listPlugins", "classVamp_1_1HostExt_1_1PluginLoader.html#aff51b52bb68aa2934ccf26ad1d284f28", null ],
    [ "listPluginsIn", "classVamp_1_1HostExt_1_1PluginLoader.html#a04c207e7c936710d70f31dba36f1773c", null ],
    [ "listPluginsNotIn", "classVamp_1_1HostExt_1_1PluginLoader.html#a0bd7c1f000b6e5411cffd908bd77f931", null ],
    [ "loadPlugin", "classVamp_1_1HostExt_1_1PluginLoader.html#a964689eb9688cd7e58e8c82ebb0d305f", null ],
    [ "composePluginKey", "classVamp_1_1HostExt_1_1PluginLoader.html#acc6865d27825c100d7b6f9ed6ecf5207", null ],
    [ "getPluginCategory", "classVamp_1_1HostExt_1_1PluginLoader.html#a52746ea66339ad981b868a031a3b382d", null ],
    [ "getLibraryPathForPlugin", "classVamp_1_1HostExt_1_1PluginLoader.html#a4bbcb7873e617bbc9f79eade1f90f7ad", null ],
    [ "m_impl", "classVamp_1_1HostExt_1_1PluginLoader.html#ac12254d823f6d63cb8ce82a07bdcb072", null ],
    [ "m_instance", "classVamp_1_1HostExt_1_1PluginLoader.html#af89caf5f838a586b117c417260b7a116", null ]
];