var classVamp_1_1PluginAdapter =
[
    [ "PluginAdapter", "classVamp_1_1PluginAdapter.html#a16312efd629b7063d7b6d67889a2c15a", null ],
    [ "~PluginAdapter", "classVamp_1_1PluginAdapter.html#a9612c9df7d4844959a36921d43d4bd50", null ],
    [ "createPlugin", "classVamp_1_1PluginAdapter.html#a3f387e7e37409e00d32477903b5b13d3", null ],
    [ "getDescriptor", "classVamp_1_1PluginAdapter.html#ad24595002512f9f00e8e45216d6f5dfb", null ],
    [ "m_impl", "classVamp_1_1PluginAdapter.html#a0e3594c54884efd5a7ef38030645745b", null ]
];