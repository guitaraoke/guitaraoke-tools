var classVamp_1_1FFT =
[
    [ "forward", "classVamp_1_1FFT.html#a219e3f6f0392dbdacad4a47d912f9aca", null ],
    [ "inverse", "classVamp_1_1FFT.html#aff98a3610275024cd3cb421e6283ee7f", null ]
];