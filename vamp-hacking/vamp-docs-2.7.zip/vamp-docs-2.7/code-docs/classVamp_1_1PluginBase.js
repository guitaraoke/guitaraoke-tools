var classVamp_1_1PluginBase =
[
    [ "ParameterDescriptor", "structVamp_1_1PluginBase_1_1ParameterDescriptor.html", "structVamp_1_1PluginBase_1_1ParameterDescriptor" ],
    [ "ParameterList", "classVamp_1_1PluginBase.html#a3b6bb4bbd86affe1ca9deceea1aad4f8", null ],
    [ "ProgramList", "classVamp_1_1PluginBase.html#a7f66f00437b21e5f694fe02356b12f20", null ],
    [ "~PluginBase", "classVamp_1_1PluginBase.html#a3773b37c658cf22d7f135c575a28f5c5", null ],
    [ "getVampApiVersion", "classVamp_1_1PluginBase.html#ab4aa9c3e6f6dd9addbc095463c9fb772", null ],
    [ "getIdentifier", "classVamp_1_1PluginBase.html#ad1c6dfc77aa03d937a885b7f08258f4a", null ],
    [ "getName", "classVamp_1_1PluginBase.html#a18619d5097e444ecefee0c359da53232", null ],
    [ "getDescription", "classVamp_1_1PluginBase.html#a59153a02364f75fff46973b2072e9e5a", null ],
    [ "getMaker", "classVamp_1_1PluginBase.html#a53d9918bf9ef4d12feedf66b2b26c637", null ],
    [ "getCopyright", "classVamp_1_1PluginBase.html#ab7e9dedbe965f5ab9018b72920fe7661", null ],
    [ "getPluginVersion", "classVamp_1_1PluginBase.html#a63f686d77bc3d6b807e7944cdde83151", null ],
    [ "getParameterDescriptors", "classVamp_1_1PluginBase.html#a0c24ff6a43c681198dc9497287a26e3a", null ],
    [ "getParameter", "classVamp_1_1PluginBase.html#aa813d61077080ec95487d2a0227cc51b", null ],
    [ "setParameter", "classVamp_1_1PluginBase.html#a6c718ce822f7b73b98940d59dcaa9366", null ],
    [ "getPrograms", "classVamp_1_1PluginBase.html#aaf6febff0ab4daf4a5089c98a67f4df8", null ],
    [ "getCurrentProgram", "classVamp_1_1PluginBase.html#aac38c5dc6e87208616122897518ca3d5", null ],
    [ "selectProgram", "classVamp_1_1PluginBase.html#aadd3a547ef140bae200473a9518e3353", null ],
    [ "getType", "classVamp_1_1PluginBase.html#a2da03e9ced8dc7e4382205e6dc05dbff", null ]
];